Run from the project root with:

uv run python -m process_sim.main

Alternative:
uv run python run_sim.py
